b = [0, 5, 0];
a = [1, -1/2, -3/8];
[r, p, k] = residuez(b, a);
display(r)
display(p)
display(k)
